package frontend.SyntaxError;

import frontend.SyntaxError.ErrorType;
import java.io.FileWriter;
import java.io.IOException;

public class SyntaxErrorHandler {
    private static SyntaxErrorHandler instance;
    private String ErrorFileName = "error.txt";

    public static SyntaxErrorHandler getInstance() {
        if (instance == null) {
            instance = new SyntaxErrorHandler();
        }
        return instance;
    }

    public void ClearError_txt() {
        try {
            FileWriter fileWriter = new FileWriter(ErrorFileName);
            fileWriter.write("");
            fileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void WriteSyntaxError(ErrorType errorType, int line) {
        try {
            FileWriter fileWriter = new FileWriter(ErrorFileName, true);
            fileWriter.write(errorType + " " + line + "\n");
            fileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
