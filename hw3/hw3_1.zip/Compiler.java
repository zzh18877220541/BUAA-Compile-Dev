import frontend.SyntaxError.SyntaxErrorHandler;
import frontend.lexer.Lexer;
import frontend.lexer.SourceFile;
import frontend.lexer.Token;
import frontend.lexer.TokenList;
import frontend.parser.CompUnit;
import frontend.parser.CompUnitParser;

public class Compiler {
    public static void main(String[] args) {
        String inputFile = "testfile.txt";
        String outputFile = "parser.txt";
        String errorFile = "error.txt";

        SyntaxErrorHandler.getInstance().ClearError_txt();
        SourceFile sourceFile = new SourceFile(inputFile);
        Lexer lexer = new Lexer(sourceFile);
        TokenList tokenList = new TokenList();
        lexer.TokenToList(tokenList);

        CompUnitParser compUnitParser = new CompUnitParser(tokenList);
        CompUnit compUnit = compUnitParser.parseCompUnit();
        compUnit.toSyntaxString();
    }
}
