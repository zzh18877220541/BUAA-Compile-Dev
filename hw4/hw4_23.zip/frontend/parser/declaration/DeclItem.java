package frontend.parser.declaration;

import frontend.parser.SyntaxOutput;

public interface DeclItem extends SyntaxOutput {

}
