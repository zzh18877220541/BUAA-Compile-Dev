package frontend.symbol;

public enum SymbolType {
    ConstChar, Char, ConstInt, Int, ConstCharArray, CharArray,
    ConstIntArray, IntArray, VoidFunc, CharFunc, IntFunc
}
