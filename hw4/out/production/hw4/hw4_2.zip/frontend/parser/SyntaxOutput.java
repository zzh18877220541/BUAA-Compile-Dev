package frontend.parser;

public interface SyntaxOutput {
    public String toSyntaxString();
}
